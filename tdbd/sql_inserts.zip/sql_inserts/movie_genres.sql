SET search_path TO movies_data;

-- Movie ID: 11
INSERT INTO movie_genre (movie_id, genre_id) VALUES (11, 12);
INSERT INTO movie_genre (movie_id, genre_id) VALUES (11, 28);
INSERT INTO movie_genre (movie_id, genre_id) VALUES (11, 878);

-- Movie ID: 550
INSERT INTO movie_genre (movie_id, genre_id) VALUES (550, 18);
INSERT INTO movie_genre (movie_id, genre_id) VALUES (550, 53);

-- Movie ID: 13
INSERT INTO movie_genre (movie_id, genre_id) VALUES (13, 35);
INSERT INTO movie_genre (movie_id, genre_id) VALUES (13, 18);
INSERT INTO movie_genre (movie_id, genre_id) VALUES (13, 10749);

-- Movie ID: 120
INSERT INTO movie_genre (movie_id, genre_id) VALUES (120, 12);
INSERT INTO movie_genre (movie_id, genre_id) VALUES (120, 14);
INSERT INTO movie_genre (movie_id, genre_id) VALUES (120, 28);


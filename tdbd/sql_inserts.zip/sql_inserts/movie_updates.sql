SET search_path TO movies_data;

-- Movie ID: 11
UPDATE movie SET producer_id = 1 WHERE movie_id = 11;

-- Movie ID: 550
UPDATE movie SET producer_id = 711 WHERE movie_id = 550;

-- Movie ID: 13
UPDATE movie SET producer_id = 4 WHERE movie_id = 13;

-- Movie ID: 120
UPDATE movie SET producer_id = 12 WHERE movie_id = 120;


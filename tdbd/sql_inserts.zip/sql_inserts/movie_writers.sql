SET search_path TO movies_data;

-- Movie ID: 11
INSERT INTO movie_writer (movie_id, writer_id) VALUES (11, 1);

-- Movie ID: 550
INSERT INTO movie_writer (movie_id, writer_id) VALUES (550, 7469);

-- Movie ID: 13
INSERT INTO movie_writer (movie_id, writer_id) VALUES (13, 27);

-- Movie ID: 120
INSERT INTO movie_writer (movie_id, writer_id) VALUES (120, 128);
INSERT INTO movie_writer (movie_id, writer_id) VALUES (120, 126);
INSERT INTO movie_writer (movie_id, writer_id) VALUES (120, 108);


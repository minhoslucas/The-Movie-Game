SET search_path TO movies_data;

-- Movie ID: 11
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 2);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 3);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 4);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 5);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 12248);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 6);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 130);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 24343);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 24342);
INSERT INTO acted_in (movie_id, actor_id) VALUES (11, 15152);

-- Movie ID: 550
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 819);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 287);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 1283);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 7470);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 7499);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 7471);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 7497);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 7498);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 7472);
INSERT INTO acted_in (movie_id, actor_id) VALUES (550, 7219);

-- Movie ID: 13
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 31);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 32);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 33);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 35);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 34);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 37821);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 204997);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 9640);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 6751);
INSERT INTO acted_in (movie_id, actor_id) VALUES (13, 3817610);

-- Movie ID: 120
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 109);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 1327);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 110);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 1328);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 65);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 882);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 113);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 48);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 1329);
INSERT INTO acted_in (movie_id, actor_id) VALUES (120, 1330);


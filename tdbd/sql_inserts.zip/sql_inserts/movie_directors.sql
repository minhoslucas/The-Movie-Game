SET search_path TO movies_data;

-- Movie ID: 11
INSERT INTO movie_director (movie_id, director_id) VALUES (11, 1);

-- Movie ID: 550
INSERT INTO movie_director (movie_id, director_id) VALUES (550, 7467);

-- Movie ID: 13
INSERT INTO movie_director (movie_id, director_id) VALUES (13, 24);

-- Movie ID: 120
INSERT INTO movie_director (movie_id, director_id) VALUES (120, 108);

